//
//  DetailViewController.swift
//  Reversi
//
//  Created by Nazari on 15/03/2017.
//  Copyright © 2017 Puia. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController
{
    @IBOutlet weak var pixView: TinyPixView!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}

